package com.Harun.Techstop.controller;

import com.Harun.Techstop.CartList.CartData;
import com.Harun.Techstop.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Home controllers
 */
@Controller
public class HomeController {

	@Autowired
	private ProductService productService;

	/**
	 * user/ admin accessing home
	 * 
	 * @param model
	 * @return
	 */
	@GetMapping({ "/", "/home" })
	public String homePage(Model model) {
		model.addAttribute("cartCount", CartData.cart.size());
		model.addAttribute("products", productService.getAll());
		return "home";
	}



	/**
	 * accessing shop
	 * 
	 * @param model
	 * @return
	 */
	@GetMapping("/shop")
	public String shop(Model model) {
		model.addAttribute("products", productService.getAll());
		return "store";
	}



	/**
	 * view shop by product id
	 * 
	 * @param model
	 * @param id
	 * @return
	 */
	@GetMapping("/shop/viewproduct/{id}")
	public String viewProduct(Model model, @PathVariable int id) {
		model.addAttribute("product", productService.getById(id).get());
		return "viewProduct";
	}

}
