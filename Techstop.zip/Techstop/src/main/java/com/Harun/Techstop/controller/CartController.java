package com.Harun.Techstop.controller;

import com.Harun.Techstop.CartList.CartData;
import com.Harun.Techstop.Entity.Order;
import com.Harun.Techstop.Entity.Product;
import com.Harun.Techstop.Entity.User;
import com.Harun.Techstop.Repository.OrderRepo;
import com.Harun.Techstop.Repository.UserRepo;
import com.Harun.Techstop.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
public class CartController {
	@Autowired
	private ProductService productService;
	@Autowired
	private UserRepo userRepo;
	@Autowired
	private OrderRepo orderRepo;

	/**
	 * adding the product to cart
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping("/addToCart/{id}")
	public String AddCart(@PathVariable int id) {
		CartData.cart.add(productService.getById(id).get());
		return "redirect:/shop";
	}

	@GetMapping("/addToOrder/{id}")
	public String AddOrder(@PathVariable int id) {
		CartData.cart.add(productService.getById(id).get());
		return "redirect:/orderPlaced";
	}

	/**
	 * viewing the cart
	 * 
	 * @param model
	 * @return
	 */
	@GetMapping("/viewOrders")
	public String getProducts(Model model) {

		model.addAttribute("products", productService.getAll());
		return "products";
	}

	@GetMapping("/orderPlaced")
	public String orderPlaced(Model model, Principal principal) {
		String username = principal.getName();

		List<Product> products = CartData.cart;
		List<Integer> productList = new ArrayList<>();
		for (Product prod : products) {
			productList.add(prod.getId());
		}
		String listProducts = productList.toString();
		System.out.println(listProducts);
		Order order = new Order();
		order.setUserName(username);
		order.setProductIdsList(listProducts);
		Order orderSaved = orderRepo.save(order);
		User user = userRepo.findUserByEmail(username);
		model.addAttribute("user", user);
		model.addAttribute("cart1", CartData.cart);

		return "orderPlaced";
	}

	@GetMapping("/cart")
	public String getCart(Model model) {
		model.addAttribute("cart", CartData.cart);
		return "cart";
	}

	/**
	 * removing the item by index from cart
	 * 
	 * @param index
	 * @return
	 */
	@GetMapping("/cart/removeItem/{index}")
	public String removeCartItem(@PathVariable int index) {
		CartData.cart.remove(index);
		return "redirect:/cart";
	}

	@GetMapping("/deleteOrder/{id}")
	public String deleteOrder(@PathVariable(value = "id") Integer id) {
		productService.deleteById(id);
		return "redirect:/";

	}
}
