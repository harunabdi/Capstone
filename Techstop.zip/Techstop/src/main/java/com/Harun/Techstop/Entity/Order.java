package com.Harun.Techstop.Entity;


import javax.persistence.*;

@Entity
@Table(name = "orders")

public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String userName;
    private String productIdsList;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProductIdsList() {
        return productIdsList;
    }

    public void setProductIdsList(String productIdsList) {
        this.productIdsList = productIdsList;
    }
}

