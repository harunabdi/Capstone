package com.Harun.Techstop.controller;


import com.Harun.Techstop.DTO.ProductDTO;
import com.Harun.Techstop.Entity.Product;
import com.Harun.Techstop.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;



@Controller
public class AdminController {

	@Autowired
	private ProductService productService;

	/**
	 * admin to delete the product by id
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping("/admin/product/delete/{id}")
	public String deletePro(@PathVariable int id) {
		productService.deleteById(id);
		return "redirect:/admin/products";
	}

	/**
	 * admin to view the products
	 * 
	 * @param model
	 * @return
	 */
	@GetMapping("/admin/products")
	public String getPro(Model model) {
		model.addAttribute("products", productService.getAll());
		return "products";
	}

	/**
	 * admin to add the product
	 * 
	 * @param model
	 * @return
	 */
	@GetMapping("/admin/products/add")
	public String addPro(Model model) {
		model.addAttribute("productDTO", new ProductDTO());
		return "productAdd";
	}

	/**
	 * admin to add the product
	 * 
	 * 
	 */
	@PostMapping("/admin/products/add")
	public String addProduct(@ModelAttribute("productDTO") ProductDTO productDto) {
		Product product = new Product();
		product.setId(productDto.getId());
		product.setName(productDto.getName());
		product.setPrice(productDto.getPrice());
		productService.addProduct(product);
		return "redirect:/admin/products";
	}

	/**]
	 * admin to update the product by id
	 * 
	 */

	@GetMapping("/admin/product/update/{id}")
	public String updateProd(@PathVariable int id, Model model) {
		Product product = productService.getById(id).get();
		ProductDTO productDTO = new ProductDTO();
		productDTO.setId(product.getId());
		productDTO.setPrice(product.getPrice());
		productDTO.setName(product.getName());
		model.addAttribute("productDTO", productDTO);
		return "productAdd";
	}

}
