package com.Harun.Techstop.CartList;


import java.util.ArrayList;
import java.util.List;

import com.Harun.Techstop.Entity.Product;

public class CartData {
    public static List<Product> cart;
    static {
        cart= new ArrayList<>();
    }
}
