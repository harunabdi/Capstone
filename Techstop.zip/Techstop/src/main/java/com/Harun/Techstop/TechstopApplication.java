package com.Harun.Techstop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class TechstopApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechstopApplication.class, args);
	}

}