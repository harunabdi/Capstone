package com.example.Techstop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechstopApplicationTests {

	@Test
	void contextLoads() {
	}

}
